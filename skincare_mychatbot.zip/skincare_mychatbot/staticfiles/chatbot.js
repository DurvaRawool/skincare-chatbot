document.addEventListener("DOMContentLoaded", function () {
    loadPreviousChats(); // Load chats on page load

    document.getElementById("search-btn").addEventListener("click", function () {
        let query = document.getElementById("chat-input").value;

        fetch("/chatbot/", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "X-CSRFToken": getCSRFToken(),
            },
            body: "user_input=" + encodeURIComponent(query),
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === "success") {
                displayChat(query, data.response);
                loadPreviousChats(); // Reload chat history
            } else {
                console.error("Error:", data.message);
            }
        })
        .catch(error => console.error("Error in fetch:", error));
    });
});

document.getElementById("skinAnalysisBtn").addEventListener("click", function() {
    window.location.href = "/skin-analysis/";
});


function loadPreviousChats() {
    fetch("/previous-chats/")
        .then(response => response.json())
        .then(data => {
            let chatList = document.getElementById("previous-chats-list");
            chatList.innerHTML = ""; // Clear previous list

            data.chats.forEach(chat => {
                let chatItem = document.createElement("div");
                chatItem.classList.add("chat-item");
                chatItem.textContent = chat.query;
                
                // Load chat on click
                chatItem.addEventListener("click", function () {
                    displayChat(chat.query, chat.response);
                });

                chatList.appendChild(chatItem);
            });
        })
        .catch(error => console.error("Error loading previous chats:", error));
}

function displayChat(userQuery, botResponse) {
    let output = document.querySelector(".chat-output");
    
    output.innerHTML += `<div class="message user-message"><p><strong>You:</strong> ${userQuery}</p></div>`;
    output.innerHTML += `<div class="message bot-message"><p><strong>DermaGPT:</strong> ${botResponse}</p></div>`;
    
    output.scrollTop = output.scrollHeight; // Auto-scroll to bottom
}

function getCSRFToken() {
    let tokenElement = document.querySelector("[name=csrfmiddlewaretoken]");
    return tokenElement ? tokenElement.value : "";
}

document.addEventListener("DOMContentLoaded", function () {
    let shareButton = document.getElementById("shareChat");

    if (shareButton) {
        shareButton.addEventListener("click", function () {
            console.log("Share button clicked!");  // Debugging

            let chatMessages = document.querySelectorAll(".chat-container .message"); // Adjust selector
            let chatText = "";

            chatMessages.forEach(msg => {
                chatText += msg.innerText + "\n";
            });

            console.log("Chat text:", chatText);  // Debugging

            if (!chatText.trim()) {
                alert("No chat content to share!");
                return;
            }

            let encodedChat = encodeURIComponent(chatText);
            let whatsappLink = `https://api.whatsapp.com/send?text=${encodedChat}`;
            let emailLink = `mailto:?subject=Shared%20Chat&body=${encodedChat}`;

            let shareDiv = document.getElementById("shareOptions");
            shareDiv.innerHTML = `
                <a href="${whatsappLink}" target="_blank" class="btn btn-success">Share on WhatsApp</a>
                <a href="${emailLink}" target="_blank" class="btn btn-info">Share via Email</a>
            `;
            shareDiv.style.display = "block";

            // Web Share API (For mobile users)
            if (navigator.share) {
                navigator.share({
                    title: "DermaGPT Chat",
                    text: chatText
                }).catch(err => console.log("Sharing failed:", err));
            }
        });
    }
});




ocument.getElementById('search-button').addEventListener('click', function() {
    const userQuery = document.getElementById('user-input').value;
    const remedyTitle = document.getElementById('remedy-title').value; // Get remedy title from input

    // Call the existing function to get AI response
    fetch('/get-ai-response/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': getCSRFToken(),
        },
        body: JSON.stringify({ user_query: userQuery })
    })
    .then(response => response.json())
    .then(data => {
        displayChat(userQuery, data.response);
        
        // Save the remedy title after getting the response
        fetch('/save-remedy/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCSRFToken(),
            },
            body: JSON.stringify({ remedy_title: remedyTitle, user_query: userQuery }) // Send remedy title
        })
        .then(response => response.json())
        .then(data => {
            console.log(data.message); // Log success message
        });
    });
});