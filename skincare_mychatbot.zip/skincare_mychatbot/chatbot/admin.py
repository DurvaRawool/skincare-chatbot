from django.contrib import admin
from .models import UserLoginHistory
from .models import SkinAnalysis

@admin.register(UserLoginHistory)
class UserLoginHistoryAdmin(admin.ModelAdmin):
    list_display = ['user', 'login_time', 'ip_address', 'user_agent']
    list_filter = ['login_time']

@admin.register(SkinAnalysis)
class SkinAnalysisAdmin(admin.ModelAdmin):
    list_display = ('user', 'get_skin_type', 'timestamp')
    search_fields = ('user__username', 'skin_type')

    def get_skin_type(self, obj):
        return obj.skin_type  # Ensure skin_type exists in the model

    get_skin_type.admin_order_field = 'skin_type'  # Allows sorting
    get_skin_type.short_description = 'Skin Type'  # Label in the admin panel