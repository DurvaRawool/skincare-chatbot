from django.db import models
from django.contrib.auth.models import User

from django.db import models

class ChatHistory(models.Model):
    user_email = models.CharField(max_length=255)
    query = models.TextField(default="Unknown Query")
    response = models.TextField(default="Default Response")
    timestamp = models.DateTimeField(auto_now_add=True)
    session_id = models.CharField(max_length=100, blank=True, null=True)  # <-- Add this line

    def __str__(self):
        return f"{self.user_email}: {self.query}"


class UserLoginHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    login_time = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"{self.user.username} - {self.login_time}"

class SkinAnalysis(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    session_id = models.CharField(max_length=100)
    skin_type = models.CharField(max_length=50)
    breakouts = models.CharField(max_length=10)
    visible_pores = models.CharField(max_length=10)
    dull_skin = models.CharField(max_length=10)
    pigmentation = models.CharField(max_length=10)
    concerns = models.TextField()  # e.g., "Dry, Breakouts: Yes, Pigmentation: No"
    remedies = models.TextField()  # Joined remedy string
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.skin_type} ({self.timestamp.strftime('%Y-%m-%d')})"



class ChatTitle(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=255)
    session_id = models.CharField(max_length=100)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} ({self.user.username})"

class Feedback(models.Model):
    RATING_CHOICES = [(i, str(i)) for i in range(1, 6)]  # 1 to 5 stars

    rating = models.IntegerField(choices=RATING_CHOICES)
    comment = models.TextField(null=True, blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback ({self.rating} stars)"