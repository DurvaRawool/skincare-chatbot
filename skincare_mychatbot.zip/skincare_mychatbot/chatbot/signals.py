from django.contrib.auth.signals import user_logged_in
from django.utils.timezone import now
from django.dispatch import receiver
from django.core.exceptions import ObjectDoesNotExist
from django.contrib.sessions.models import Session
from .models import UserLoginHistory

@receiver(user_logged_in)
def log_user_login(sender, request, user, **kwargs):
    ip = get_client_ip(request)
    user_agent = request.META.get('HTTP_USER_AGENT', '')

    UserLoginHistory.objects.create(user=user, login_time=now(), ip_address=ip, user_agent=user_agent)

def get_client_ip(request):
    """Extract client IP address from request."""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip
