from django.db import IntegrityError
import openai
from django.shortcuts import get_object_or_404, render, redirect
from django.http import JsonResponse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils.crypto import get_random_string
from .forms import FeedbackForm
from .models import ChatTitle, SkinAnalysis
from .models import ChatHistory

# Set OpenAI API Key (Use environment variables in production)
openai.api_key = "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"

remedies = {
    "acne": """
        <h3>Neem & Turmeric Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Neem (Azadirachta indica) leaves - 1 cup</li>
            <li>Turmeric (Curcuma longa) powder - 1 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind neem leaves to a paste.</li>
            <li>Add turmeric powder and gram flour. Mix well.</li>
            <li>Add rose water gradually to get a smooth paste.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Neem is antiviral, antifungal, and antibacterial. It prevents acne and pimples.</li>
            <li>Turmeric brightens complexion and reduces pigmentation.</li>
            <li>Gram flour deeply cleanses the skin, removing dirt.</li>
        </ul><br>

            <h3>Aloe Vera & Rose Face Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Aloe Vera (Aloe barbadensis) gel - 2 tbsp</li>
            <li>Rose (Rosa centifolia) powder - 1 tsp</li>
            <li>Sandalwood (Santalum album) powder - 1⁄2 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mix all ingredients well.</li>
            <li>Apply on clean face.</li>
            <li>Wash off after 20 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Aloe vera hydrates, brightens and tightens skin.</li>
            <li>Rose powder cools, calms and evens out complexion.</li>
            <li>Sandalwood soothes irritation and reduces acne.</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

            <h3> Mint Toner for Oily Skin</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Mint (Mentha arvensis) leaves - 1 cu/li>
            <li>CApple cider vinegar - 1⁄4 cup</li>
            <li>Cucumber (Cucumis sativus) - 1⁄2</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Boil mint leaves in 2 cups water for 10 mins.</li>
            <li>Strain and let it cool.</li>
            <li>Strain and let it cool.</li>
            <li>Apply with cotton over face and neck.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Mint controls excess oil, reduces acne.</li>
            <li>Apple cider vinegar cleanses, tightens pores.</li>
            <li>Cucumber hydrates and nourishes the skin.</li>
        </ul><br>

        <h3>Banana & Oat Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Banana (Musa acuminata) - 1</li>
            <li>Oats (Avena sativa) - 3 tbsp</li>
            <li>Milk - 2 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash banana well. Add oats and milk.</li>
            <li>Mix into a smooth scrub.</li>
            <li>Gently massage on face. Rinse off.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Banana hydrates and nourishes, suitable for dry skin.</li>
            <li>Oats exfoliate dead skin cells, reduces acne.</li>
            <li>Milk proteins soften and tighten the skin.</li>
        </ul><br>

         <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>

        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>

        <h3> Tomato & Oats Scrub</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Tomato (Solanum lycopersicum) - 1</li>
            <li>Oats (Avena sativa) - 3 tbsp</li>
            <li>Lemon (Citrus limon) juice - 1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend tomato to a smooth paste.</li>
            <li>Add oats and mix well to get a scrub.</li>
            <li>Add lemon juice and apply on face./li>
            <li>Gently scrub in circular motions. Wash off.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Tomato hydrates, evens skin tone and shrinks pores.</li>
            <li>Oats exfoliate dead cells, reduce acne.</li>
            <li>Lemon bleaches skin and tightens pores.</li>
        </ul><br>

        <h3> Papaya & Gram Flour Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Papaya (Carica papaya) - 1 cup</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend papaya to smooth paste.</li>
            <li>Add gram flour and turmeric. Mix well.</li>
            <li>Gently scrub face in circular motions.</li>
            <li>Wash off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Papaya cleanses skin, removes dead cells.</li>
            <li>Gram flour exfoliates and deeply cleanses.</li>
            <li>Turmeric antibacterial, reduces acne & scars.</li>
        </ul><br>

        <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        </ol><br>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        </ul><br>

        <h3>Aloe Vera &	Tea	Tree Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li>Aloe vera gel -	1⁄4	cup</li>
            <li> Green	tea	- 2 bags</li>
            <li>Tea	tree essential	oil	- 3 drops</li>
        </ul><br>
         <h4> Process:</h4><br>
         <ol>
            <li>Steep green	tea	bags in	1 cup hot water	for	5 mins.</li>
            <li>Let	cool and mix with aloe vera gel.</li>
            <li> Add tea tree oil and transfer to bottle.</li>
            <li>Apply on skin after	cleansing.</li>
         </ol><br>
         <h4>Uses & Benefits:</h4><br>
         <ul>
            <li> Aloe vera soothes,	cools and hydrates.</li>
            <li> Green tea	antioxidants rejuvenate	skin.</li>
            <li> Tea tree oil	antibacterial,	prevents acne.</li>
         </ul><br>
    """,

    "pimple":"""
        <h3>Neem & Turmeric Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Neem (Azadirachta indica) leaves - 1 cup</li>
            <li>Turmeric (Curcuma longa) powder - 1 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind neem leaves to a paste.</li>
            <li>Add turmeric powder and gram flour. Mix well.</li>
            <li>Add rose water gradually to get a smooth paste.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Neem is antiviral, antifungal, and antibacterial. It prevents acne and pimples.</li>
            <li>Turmeric brightens complexion and reduces pigmentation.</li>
            <li>Gram flour deeply cleanses the skin, removing dirt.</li>
        </ul><br>

        <h3>Orange & Carrot Face Mask</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Orange (Citrus sinensis) - 1</li>
            <li>Carrots (Daucus carota subsp. sativus) - 2</li>
            <li>Multani mitti - 2 tbsp</li>
            <li>Rose water - as needed</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grate the carrots. Extract juice from orange.</li>
            <li>Mix both juices with multani mitti.</li>
            <li>Add rose water to get a smooth paste.</li>
            <li>Apply on face. Wash off after 15 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Oranges improve skin elasticity and even out complexion.</li>
            <li>Carrots are antibacterial. They hydrate and repair skin.</li>
            <li>Multani mitti absorbs excess oils, treats pimples.</li>
            <li>Rose water tones, freshens up the skin.</li>
        </ul><br>

        <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>
    """,

    "dead cells":"""
    <h3>Papaya-Cinnamon Exfoliating Scrub</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Papaya (Carica papaya) - 1 cup</li>
            <li>Cinnamon (Cinnamomum verum) - 1 tsp</li>
            <li>Honey - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash papaya well. Add cinnamon and honey.</li>
            <li>Mix thoroughly to get a coarse scrub.</li>
            <li>Gently scrub face in circles. Rinse with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Papaya removes dead cells, evens out skin.</li>
            <li>Cinnamon improves blood circulation giving a natural glow.</li>
            <li>Honey moisturizes and nourishes the skin.</li>
        </ul><br>

        <h3>Avocado & Yogurt Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Avocado (Persea americana) - 1⁄2</li>
            <li>Yogurt (Curd) - 1 tbsp</li>
            <li>Lemon (Citrus limon) juice - 1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Scoop out avocado pulp into a bowl.</li>
            <li>Add yogurt and lemon juice. Mix well.</li>
            <li>Apply evenly on face and neck.</li>
            <li>Wash off with water after 20 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Avocado hydrates and repairs skin, boosts collagen.</li>
            <li>Yogurt exfoliates dead cells, reduces pigmentation.</li>
            <li>Lemon brightens and tightens the skin.</li>
        </ul><br>

        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>

        <h3>Strawberry & Honey Scrub</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Strawberry (Fragaria ananassa) - 5-6</li>
            <li>Honey - 1 tbsp</li>
            <li>Sugar (Sucrose) - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash strawberries into a pulp.</li>
            <li>Add honey and sugar. Mix to a coarse scrub.</li>
            <li>Gently massage on damp face.</li>
            <li>Rinse with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Strawberry cleanses pores, exfoliates dead cells.</li>
            <li>Honey nourishes, moisturizes and softens skin.</li>
            <li>Sugar particles remove dirt and brighten skin.</li>
        </ul><br>

        <h3> Papaya & Gram Flour Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Papaya (Carica papaya) - 1 cup</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend papaya to smooth paste.</li>
            <li>Add gram flour and turmeric. Mix well.</li>
            <li>Gently scrub face in circular motions.</li>
            <li>Wash off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Papaya cleanses skin, removes dead cells.</li>
            <li>Gram flour exfoliates and deeply cleanses.</li>
            <li>Turmeric antibacterial, reduces acne & scars.</li>
        </ul><br>

        <h3>Walnut & Coffee	Scrub</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Walnut-(5-6).</li>
            <li> Coffee powder-1 tbsp</li>
            <li> Brown sugar - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Crush walnuts to coarse powder.</li>
            <li> Add coffee	and	brown sugar.</li>
            <li>Gently scrub face in circles.</li>
            <li> Rinse off	with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Walnut	exfoliates,	improves skin texture.</li>
            <li> Coffee	stimulates blood flow, rejuvenates skin.</li>
            <li> Brown	sugar removes	dead cells,	dirt.</li>
        </ul><br>

        <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>
        </ul><br>

        <h3>Rice Water Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Rice (Oryza sativa) -	1⁄4	cup</li>
            <li> Plain yogurt -	2 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ul>
            <li> Boil rice in 2 cups water for	15	mins.</li>
            <li> Strain	out	rice water and	let	cool</li>
            <li> Add yogurt	and	mix	well.</li>
            <li> Apply on face with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rice water	tightens pores,	smooths	wrinkles.</li>
            <li> Yogurt	hydrates, exfoliates dead cells.</li>
        </ul><br>
    """,

    "brightens":"""
    <h3>Aloe Vera & Rose Face Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Aloe Vera (Aloe barbadensis) gel - 2 tbsp</li>
            <li>Rose (Rosa centifolia) powder - 1 tsp</li>
            <li>Sandalwood (Santalum album) powder - 1⁄2 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mix all ingredients well.</li>
            <li>Apply on clean face.</li>
            <li>Wash off after 20 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Aloe vera hydrates, brightens and tightens skin.</li>
            <li>Rose powder cools, calms and evens out complexion.</li>
            <li>Sandalwood soothes irritation and reduces acne.</li>
        </ul><br>

        <h3>Rosemary & Orange Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Rosemary (Rosmarinus officinalis)	- 1⁄4 cup</li>
            <li> Orange	(Citrus	sinensis) peel	- 2	tbsp</li>
            <li>Apple cider	vinegar	- 2	tbsp</li>
            <li>Witch hazel	- 1⁄4 cup</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ul>
             <li> Boil rosemary	and	orange	peel in	2 cups water.</li>
             <li> Strain and let cool. Mix	in	vinegar	and	witch	hazel.</li>
             <li>Transfer	to	bottle	and	refrigerate.</li>
             <li> Apply	on	skin with cotton pad.</li>
        </ul><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li> Rosemary improves	blood circulation.</li>
            <li> Orange	peel antibacterial,	brightens	skin.</li>
            <li> Apple	cider vinegar balances pH.</li>
            <li>Witch hazel	tones and firms	skin.</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>

        <h3>Strawberry & Honey Scrub</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Strawberry (Fragaria ananassa) - 5-6</li>
            <li>Honey - 1 tbsp</li>
            <li>Sugar (Sucrose) - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash strawberries into a pulp.</li>
            <li>Add honey and sugar. Mix to a coarse scrub.</li>
            <li>Gently massage on damp face.</li>
            <li>Rinse with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Strawberry cleanses pores, exfoliates dead cells.</li>
            <li>Honey nourishes, moisturizes and softens skin.</li>
            <li>Sugar particles remove dirt and brighten skin.</li>
        </ul><br>
        """,
    
    "dry skin":"""
    <h3>Olive & Coconut Moisturizer</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Extra virgin olive oil - 2 tbsp</li>
            <li>Coconut (Cocos nucifera) oil - 1 tbsp</li>
            <li>Shea butter (Butyrospermum parkii) - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Melt shea butter slightly.</li>
            <li>Mix in olive and coconut oils.</li>
            <li>Apply gently on face and neck.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Olive oil nourishes skin and delays aging.</li>
            <li>Coconut oil is antimicrobial, reduces dryness.</li>
            <li>Shea butter is emollient, improves skin elasticity.</li>
        </ul><br>

        <h3>Orange & Carrot Face Mask</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Orange (Citrus sinensis) - 1</li>
            <li>Carrots (Daucus carota subsp. sativus) - 2</li>
            <li>Multani mitti - 2 tbsp</li>
            <li>Rose water - as needed</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grate the carrots. Extract juice from orange.</li>
            <li>Mix both juices with multani mitti.</li>
            <li>Add rose water to get a smooth paste.</li>
            <li>Apply on face. Wash off after 15 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Oranges improve skin elasticity and even out complexion.</li>
            <li>Carrots are antibacterial. They hydrate and repair skin.</li>
            <li>Multani mitti absorbs excess oils, treats pimples.</li>
            <li>Rose water tones, freshens up the skin.</li>
        </ul><br>

        <h3>Banana & Oat Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Banana (Musa acuminata) - 1</li>
            <li>Oats (Avena sativa) - 3 tbsp</li>
            <li>Milk - 2 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash banana well. Add oats and milk.</li>
            <li>Mix into a smooth scrub.</li>
            <li>Gently massage on face. Rinse off.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Banana hydrates and nourishes, suitable for dry skin.</li>
            <li>Oats exfoliate dead skin cells, reduces acne.</li>
            <li>Milk proteins soften and tighten the skin.</li>
        </ul><br>

        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>
        
        <h3>Multani Mitti & Rose Water Face Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Multani mitti - 2 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
            <li>Sandalwood (Santalum album) powder - 1⁄2 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mix multani mitti and sandalwood powder.</li>
            <li>Add rose water to make a smooth paste.</li>
            <li>Apply evenly on face and neck.</li>
            <li>Wash off when dry.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Multani mitti cleanses deep, removes excess oil.</li>
            <li>Rose water tones, refreshes and tightens skin</li>
            <li>Sandalwood powder cools and soothes skin.</li>
        </ul><br>
        """,

        "pigmentation":"""
        <h3>Avocado & Yogurt Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Avocado (Persea americana) - 1⁄2</li>
            <li>Yogurt (Curd) - 1 tbsp</li>
            <li>Lemon (Citrus limon) juice - 1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Scoop out avocado pulp into a bowl.</li>
            <li>Add yogurt and lemon juice. Mix well.</li>
            <li>Apply evenly on face and neck.</li>
            <li>Wash off with water after 20 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Avocado hydrates and repairs skin, boosts collagen.</li>
            <li>Yogurt exfoliates dead cells, reduces pigmentation.</li>
            <li>Lemon brightens and tightens the skin.</li>
        </ul><br>
        """,

        "dark spots":"""
        <h3>Sandalwood & Saffron Night Serum</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Sandalwood (Santalum album) powder - 1 tbsp</li>
            <li>Saffron (Crocus sativus) strands - 5-6</li>
            <li>Almond (Prunus dulcis) oil - 2 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Soak saffron in almond oil for 2 hours.</li>
            <li>Add sandalwood powder. Mix well.</li>
            <li>Gently massage 2-3 drops on face before sleeping.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Sandalwood cools and soothes skin overnight.</li>
            <li>Saffron improves complexion, reduces spots.</li>
            <li>Almond oil nourishes and moisturizes skin.</li>
        </ul><br>
        """,

        "scars": """
        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>

        <h3> Papaya & Gram Flour Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Papaya (Carica papaya) - 1 cup</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend papaya to smooth paste.</li>
            <li>Add gram flour and turmeric. Mix well.</li>
            <li>Gently scrub face in circular motions.</li>
            <li>Wash off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Papaya cleanses skin, removes dead cells.</li>
            <li>Gram flour exfoliates and deeply cleanses.</li>
            <li>Turmeric antibacterial, reduces acne & scars.</li>
        </ul><br>
        """,
        
        "skin texture":"""
        <h3>Walnut & Coffee	Scrub</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Walnut-(5-6).</li>
            <li> Coffee powder-1 tbsp</li>
            <li> Brown sugar - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Crush walnuts to coarse powder.</li>
            <li> Add coffee	and	brown sugar.</li>
            <li>Gently scrub face in circles.</li>
            <li> Rinse off	with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Walnut	exfoliates,	improves skin texture.</li>
            <li> Coffee	stimulates blood flow, rejuvenates skin.</li>
            <li> Brown	sugar	removes	dead	cells,	dirt.</li>
        </ul><br>
        """,

        "refresh skin":"""
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>
        """,

        "hydrate":"""
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>

         <h3>Aloe Vera &	Tea	Tree Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li>Aloe vera gel -	1⁄4	cup</li>
            <li> Green	tea	- 2 bags</li>
            <li>Tea	tree essential	oil	- 3 drops</li>
        </ul><br>
         <h4> Process:</h4><br>
         <ol>
            <li>Steep green	tea	bags in	1 cup hot water	for	5 mins.</li>
            <li>Let	cool and mix with aloe vera gel.</li>
            <li> Add tea tree oil and transfer to bottle.</li>
            <li>Apply on skin after	cleansing.</li>
         </ol><br>
         <h4>Uses & Benefits:</h4><br>
         <ul>
            <li> Aloe vera soothes,	cools and hydrates.</li>
            <li> Green tea	antioxidants rejuvenate	skin.</li>
            <li> Tea tree oil	antibacterial,	prevents acne.</li>
         </ul><br>

        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

         <h3>Tomato & Lemon Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Tomato (Solanum	lycopersicum) - 1⁄2</li>
            <li> Lemon	(Citrus	limon)- 1⁄2</li>
            <li> Witch	hazel -	1⁄4	cup</li>
            <li> Aloe vera gel	- 1 tbsp</li>
        <h4>Process:</h4><br>
            <li> Blend tomatoes	and	extract	juice.</li>
            <li> Mix tomato	juice with lemon juice.</li>
            <li> Add in	witch hazel	and	aloe vera gel.</li>
            <li>Apply toner	with cotton	pad	on	skin.</li>
        <h4>Uses &	Benefits:</h4><br>
            <li> Tomato	shrinks	open pores,	balances pH.</li>
            <li>Lemon bleaches skin, deeply	cleanses</li>
            <li> Witch	hazel is antibacterial, tones skin.</li>
            <li>Aloe vera soothes and hydrates skin.</li>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

        <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """,

        "nourish":"""
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>

         <h3>Aloe Vera &	Tea	Tree Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li>Aloe vera gel -	1⁄4	cup</li>
            <li> Green	tea	- 2 bags</li>
            <li>Tea	tree essential	oil	- 3 drops</li>
        </ul><br>
         <h4> Process:</h4><br>
         <ol>
            <li>Steep green	tea	bags in	1 cup hot water	for	5 mins.</li>
            <li>Let	cool and mix with aloe vera gel.</li>
            <li> Add tea tree oil and transfer to bottle.</li>
            <li>Apply on skin after	cleansing.</li>
         </ol><br>
         <h4>Uses & Benefits:</h4><br>
         <ul>
            <li> Aloe vera soothes,	cools and hydrates.</li>
            <li> Green tea	antioxidants rejuvenate	skin.</li>
            <li> Tea tree oil	antibacterial,	prevents acne.</li>
         </ul><br>

        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

         <h3>Tomato & Lemon Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Tomato (Solanum	lycopersicum) - 1⁄2</li>
            <li> Lemon	(Citrus	limon)- 1⁄2</li>
            <li> Witch	hazel -	1⁄4	cup</li>
            <li> Aloe vera gel	- 1 tbsp</li>
        <h4>Process:</h4><br>
            <li> Blend tomatoes	and	extract	juice.</li>
            <li> Mix tomato	juice with lemon juice.</li>
            <li> Add in	witch hazel	and	aloe vera gel.</li>
            <li>Apply toner	with cotton	pad	on	skin.</li>
        <h4>Uses &	Benefits:</h4><br>
            <li> Tomato	shrinks	open pores,	balances pH.</li>
            <li>Lemon bleaches skin, deeply	cleanses</li>
            <li> Witch	hazel is antibacterial, tones skin.</li>
            <li>Aloe vera soothes and hydrates skin.</li>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

        <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """,
    
        "pores":"""
        <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose water	tones,	tightens skin.</li>

        <h3>Sandalwood & Honey Face	Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Sandalwood	(Santalum album) powder	- 1	tbsp</li>
            <li> Honey - 1 tbsp</li>
            <li> Rose (Rosa centifolia)	water -	1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Mix all ingredients well.</li>
            <li> Apply pack	on	face and neck.</li>
            <li> Wash off when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Sandalwood	soothes	and	cools irritated	skin.</li>
            <li> Honey	cleanses pores,	retains	moisture.</li>
            <li> Rose	water	tones,	tightens skin.</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>

        <h3>Tomato & Lemon Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Tomato (Solanum	lycopersicum) - 1⁄2</li>
            <li> Lemon	(Citrus	limon)- 1⁄2</li>
            <li> Witch	hazel -	1⁄4	cup</li>
            <li> Aloe vera gel	- 1 tbsp</li>
        <h4>Process:</h4><br>
            <li> Blend tomatoes	and	extract	juice.</li>
            <li> Mix tomato	juice with lemon juice.</li>
            <li> Add in	witch hazel	and	aloe vera gel.</li>
            <li>Apply toner	with cotton	pad	on	skin.</li>
        <h4>Uses &	Benefits:</h4><br>
            <li> Tomato	shrinks	open pores,	balances pH.</li>
            <li>Lemon bleaches skin, deeply	cleanses</li>
            <li> Witch	hazel is antibacterial, tones skin.</li>
            <li>Aloe vera soothes and hydrates skin.</li>
    """,

    "clean":""" 
    <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>

            <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        """,

    "irritated":""" 
    <h3>Sandalwood & Honey Face	Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Sandalwood	(Santalum album) powder	- 1	tbsp</li>
            <li> Honey - 1 tbsp</li>
            <li> Rose (Rosa centifolia)	water -	1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Mix all ingredients well.</li>
            <li> Apply pack	on	face and neck.</li>
            <li> Wash off when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Sandalwood	soothes	and	cools irritated	skin.</li>
            <li> Honey	cleanses pores,	retains	moisture.</li>
            <li> Rose	water	tones,	tightens skin.</li>
        </ul><br>

        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Green Tea &	Chamomile Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li>Green tea (Camellia	sinensis) -	1 bag</li>
            <li> Chamomile	(Matricaria	chamomilla)	- 1⁄2 cup</li>
            <li> Apple cider vinegar -	2 tbsp</li>
            <li> Rosemary (Rosmarinus	officinalis) - few	drops</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ul>
            <li> Brew green	tea	bag	in	1 cup hot water	for	5 mins.</li>
            <li>Add	chamomile flowers and apple cider vinegar.</li>
            <li>Let	cool and add rosemary essential oil.</li>
            <li> Apply	on	skin with cotton pad.</li>
        </ul><br>
        <h4> Uses & Benefits:</h4><br>
        <ul>
            <li>Green tea antioxidants	rejuvenate	skin.</li>
            <li> Chamomile	calms	irritation	and	redness.</li>
            <li>Apple cider	vinegar	restores pH	balance.</li>
            <li>Rosemary antibacterial,	prevents acne.</li>
        </ul><br>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>
        """,

    "moisture":"""
    <h3>Sandalwood & Honey Face	Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Sandalwood	(Santalum album) powder	- 1	tbsp</li>
            <li> Honey - 1 tbsp</li>
            <li> Rose (Rosa centifolia)	water -	1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Mix all ingredients well.</li>
            <li> Apply pack	on	face and neck.</li>
            <li> Wash off when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Sandalwood	soothes	and	cools irritated	skin.</li>
            <li> Honey	cleanses pores,	retains	moisture.</li>
            <li> Rose	water	tones,	tightens skin.</li>
        </ul><br>
        
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

         <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """,

        "excess oil":""" 
        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        """,

        "cools":"""
        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

             <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
            """,
    
    "damage":"""
    <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>
        """
}

# Skin Analysis Data

skin_analysis_remedies = {

	"Oily":{
	"excess oil":"""
        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        """,
								
	"cools":"""
        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

        <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
            """,

    	"clean":""" 
    	<h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>

            <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        """,
	"damage":"""
    	<h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>
        """
	       },

	"Dry":{
	"dry skin":"""
   	 <h3>Olive & Coconut Moisturizer</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Extra virgin olive oil - 2 tbsp</li>
            <li>Coconut (Cocos nucifera) oil - 1 tbsp</li>
            <li>Shea butter (Butyrospermum parkii) - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Melt shea butter slightly.</li>
            <li>Mix in olive and coconut oils.</li>
            <li>Apply gently on face and neck.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Olive oil nourishes skin and delays aging.</li>
            <li>Coconut oil is antimicrobial, reduces dryness.</li>
            <li>Shea butter is emollient, improves skin elasticity.</li>
        </ul><br>

        <h3>Orange & Carrot Face Mask</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Orange (Citrus sinensis) - 1</li>
            <li>Carrots (Daucus carota subsp. sativus) - 2</li>
            <li>Multani mitti - 2 tbsp</li>
            <li>Rose water - as needed</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grate the carrots. Extract juice from orange.</li>
            <li>Mix both juices with multani mitti.</li>
            <li>Add rose water to get a smooth paste.</li>
            <li>Apply on face. Wash off after 15 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Oranges improve skin elasticity and even out complexion.</li>
            <li>Carrots are antibacterial. They hydrate and repair skin.</li>
            <li>Multani mitti absorbs excess oils, treats pimples.</li>
            <li>Rose water tones, freshens up the skin.</li>
        </ul><br>

        <h3>Banana & Oat Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Banana (Musa acuminata) - 1</li>
            <li>Oats (Avena sativa) - 3 tbsp</li>
            <li>Milk - 2 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash banana well. Add oats and milk.</li>
            <li>Mix into a smooth scrub.</li>
            <li>Gently massage on face. Rinse off.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Banana hydrates and nourishes, suitable for dry skin.</li>
            <li>Oats exfoliate dead skin cells, reduces acne.</li>
            <li>Milk proteins soften and tighten the skin.</li>
        </ul><br>

        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>
        
        <h3>Multani Mitti & Rose Water Face Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Multani mitti - 2 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
            <li>Sandalwood (Santalum album) powder - 1⁄2 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mix multani mitti and sandalwood powder.</li>
            <li>Add rose water to make a smooth paste.</li>
            <li>Apply evenly on face and neck.</li>
            <li>Wash off when dry.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Multani mitti cleanses deep, removes excess oil.</li>
            <li>Rose water tones, refreshes and tightens skin</li>
            <li>Sandalwood powder cools and soothes skin.</li>
        </ul><br>
        """,
	"moisture":"""
    	<h3>Sandalwood & Honey Face	Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Sandalwood	(Santalum album) powder	- 1	tbsp</li>
            <li> Honey - 1 tbsp</li>
            <li> Rose (Rosa centifolia)	water -	1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Mix all ingredients well.</li>
            <li> Apply pack	on	face and neck.</li>
            <li> Wash off when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Sandalwood	soothes	and	cools irritated	skin.</li>
            <li> Honey	cleanses pores,	retains	moisture.</li>
            <li> Rose	water	tones,	tightens skin.</li>
        </ul><br>
        
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

         <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """,

        "hydrate":"""
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>

         <h3>Aloe Vera &	Tea	Tree Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li>Aloe vera gel -	1⁄4	cup</li>
            <li> Green	tea	- 2 bags</li>
            <li>Tea	tree essential	oil	- 3 drops</li>
        </ul><br>
         <h4> Process:</h4><br>
         <ol>
            <li>Steep green	tea	bags in	1 cup hot water	for	5 mins.</li>
            <li>Let	cool and mix with aloe vera gel.</li>
            <li> Add tea tree oil and transfer to bottle.</li>
            <li>Apply on skin after	cleansing.</li>
         </ol><br>
         <h4>Uses & Benefits:</h4><br>
         <ul>
            <li> Aloe vera soothes,	cools and hydrates.</li>
            <li> Green tea	antioxidants rejuvenate	skin.</li>
            <li> Tea tree oil	antibacterial,	prevents acne.</li>
         </ul><br>

        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

         <h3>Tomato & Lemon Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Tomato (Solanum	lycopersicum) - 1⁄2</li>
            <li> Lemon	(Citrus	limon)- 1⁄2</li>
            <li> Witch	hazel -	1⁄4	cup</li>
            <li> Aloe vera gel	- 1 tbsp</li>
        <h4>Process:</h4><br>
            <li> Blend tomatoes	and	extract	juice.</li>
            <li> Mix tomato	juice with lemon juice.</li>
            <li> Add in	witch hazel	and	aloe vera gel.</li>
            <li>Apply toner	with cotton	pad	on	skin.</li>
        <h4>Uses &	Benefits:</h4><br>
            <li> Tomato	shrinks	open pores,	balances pH.</li>
            <li>Lemon bleaches skin, deeply	cleanses</li>
            <li> Witch	hazel is antibacterial, tones skin.</li>
            <li>Aloe vera soothes and hydrates skin.</li>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

        <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """,

    "damage":"""
    <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>
        """,
        "nourish":"""
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>

         <h3>Aloe Vera &	Tea	Tree Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li>Aloe vera gel -	1⁄4	cup</li>
            <li> Green	tea	- 2 bags</li>
            <li>Tea	tree essential	oil	- 3 drops</li>
        </ul><br>
         <h4> Process:</h4><br>
         <ol>
            <li>Steep green	tea	bags in	1 cup hot water	for	5 mins.</li>
            <li>Let	cool and mix with aloe vera gel.</li>
            <li> Add tea tree oil and transfer to bottle.</li>
            <li>Apply on skin after	cleansing.</li>
         </ol><br>
         <h4>Uses & Benefits:</h4><br>
         <ul>
            <li> Aloe vera soothes,	cools and hydrates.</li>
            <li> Green tea	antioxidants rejuvenate	skin.</li>
            <li> Tea tree oil	antibacterial,	prevents acne.</li>
         </ul><br>

        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

         <h3>Tomato & Lemon Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Tomato (Solanum	lycopersicum) - 1⁄2</li>
            <li> Lemon	(Citrus	limon)- 1⁄2</li>
            <li> Witch	hazel -	1⁄4	cup</li>
            <li> Aloe vera gel	- 1 tbsp</li>
        <h4>Process:</h4><br>
            <li> Blend tomatoes	and	extract	juice.</li>
            <li> Mix tomato	juice with lemon juice.</li>
            <li> Add in	witch hazel	and	aloe vera gel.</li>
            <li>Apply toner	with cotton	pad	on	skin.</li>
        <h4>Uses &	Benefits:</h4><br>
            <li> Tomato	shrinks	open pores,	balances pH.</li>
            <li>Lemon bleaches skin, deeply	cleanses</li>
            <li> Witch	hazel is antibacterial, tones skin.</li>
            <li>Aloe vera soothes and hydrates skin.</li>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

        <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """
		},
	
	"Normal":{
		"moisture":"""
    <h3>Sandalwood & Honey Face	Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Sandalwood	(Santalum album) powder	- 1	tbsp</li>
            <li> Honey - 1 tbsp</li>
            <li> Rose (Rosa centifolia)	water -	1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Mix all ingredients well.</li>
            <li> Apply pack	on	face and neck.</li>
            <li> Wash off when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Sandalwood	soothes	and	cools irritated	skin.</li>
            <li> Honey	cleanses pores,	retains	moisture.</li>
            <li> Rose	water	tones,	tightens skin.</li>
        </ul><br>
        
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

         <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """,

        "hydrate":"""
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>

         <h3>Aloe Vera &	Tea	Tree Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li>Aloe vera gel -	1⁄4	cup</li>
            <li> Green	tea	- 2 bags</li>
            <li>Tea	tree essential	oil	- 3 drops</li>
        </ul><br>
         <h4> Process:</h4><br>
         <ol>
            <li>Steep green	tea	bags in	1 cup hot water	for	5 mins.</li>
            <li>Let	cool and mix with aloe vera gel.</li>
            <li> Add tea tree oil and transfer to bottle.</li>
            <li>Apply on skin after	cleansing.</li>
         </ol><br>
         <h4>Uses & Benefits:</h4><br>
         <ul>
            <li> Aloe vera soothes,	cools and hydrates.</li>
            <li> Green tea	antioxidants rejuvenate	skin.</li>
            <li> Tea tree oil	antibacterial,	prevents acne.</li>
         </ul><br>

        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

         <h3>Tomato & Lemon Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Tomato (Solanum	lycopersicum) - 1⁄2</li>
            <li> Lemon	(Citrus	limon)- 1⁄2</li>
            <li> Witch	hazel -	1⁄4	cup</li>
            <li> Aloe vera gel	- 1 tbsp</li>
        <h4>Process:</h4><br>
            <li> Blend tomatoes	and	extract	juice.</li>
            <li> Mix tomato	juice with lemon juice.</li>
            <li> Add in	witch hazel	and	aloe vera gel.</li>
            <li>Apply toner	with cotton	pad	on	skin.</li>
        <h4>Uses &	Benefits:</h4><br>
            <li> Tomato	shrinks	open pores,	balances pH.</li>
            <li>Lemon bleaches skin, deeply	cleanses</li>
            <li> Witch	hazel is antibacterial, tones skin.</li>
            <li>Aloe vera soothes and hydrates skin.</li>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

        <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """,

   	"clean":""" 
    	<h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>

            <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        """
		},
	
	"Sensitive":{
	"moisture":"""
   	<h3>Sandalwood & Honey Face	Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Sandalwood	(Santalum album) powder	- 1	tbsp</li>
            <li> Honey - 1 tbsp</li>
            <li> Rose (Rosa centifolia)	water -	1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Mix all ingredients well.</li>
            <li> Apply pack	on	face and neck.</li>
            <li> Wash off when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Sandalwood	soothes	and	cools irritated	skin.</li>
            <li> Honey	cleanses pores,	retains	moisture.</li>
            <li> Rose	water	tones,	tightens skin.</li>
        </ul><br>
        
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

         <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """,

	"damage":"""
  	 <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>
        """,

        "cools":"""
        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

             <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
            """,

    "irritated":""" 
    <h3>Sandalwood & Honey Face	Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Sandalwood	(Santalum album) powder	- 1	tbsp</li>
            <li> Honey - 1 tbsp</li>
            <li> Rose (Rosa centifolia)	water -	1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Mix all ingredients well.</li>
            <li> Apply pack	on	face and neck.</li>
            <li> Wash off when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Sandalwood	soothes	and	cools irritated	skin.</li>
            <li> Honey	cleanses pores,	retains	moisture.</li>
            <li> Rose	water	tones,	tightens skin.</li>
        </ul><br>

        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Green Tea &	Chamomile Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li>Green tea (Camellia	sinensis) -	1 bag</li>
            <li> Chamomile	(Matricaria	chamomilla)	- 1⁄2 cup</li>
            <li> Apple cider vinegar -	2 tbsp</li>
            <li> Rosemary (Rosmarinus	officinalis) - few	drops</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ul>
            <li> Brew green	tea	bag	in	1 cup hot water	for	5 mins.</li>
            <li>Add	chamomile flowers and apple cider vinegar.</li>
            <li>Let	cool and add rosemary essential oil.</li>
            <li> Apply	on	skin with cotton pad.</li>
        </ul><br>
        <h4> Uses & Benefits:</h4><br>
        <ul>
            <li>Green tea antioxidants	rejuvenate	skin.</li>
            <li> Chamomile	calms	irritation	and	redness.</li>
            <li>Apple cider	vinegar	restores pH	balance.</li>
            <li>Rosemary antibacterial,	prevents acne.</li>
        </ul><br>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>
        """
		},

	"Combination":{
	"excess oil":""" 
        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        """,

    "dry skin":"""
    <h3>Olive & Coconut Moisturizer</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Extra virgin olive oil - 2 tbsp</li>
            <li>Coconut (Cocos nucifera) oil - 1 tbsp</li>
            <li>Shea butter (Butyrospermum parkii) - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Melt shea butter slightly.</li>
            <li>Mix in olive and coconut oils.</li>
            <li>Apply gently on face and neck.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Olive oil nourishes skin and delays aging.</li>
            <li>Coconut oil is antimicrobial, reduces dryness.</li>
            <li>Shea butter is emollient, improves skin elasticity.</li>
        </ul><br>

        <h3>Orange & Carrot Face Mask</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Orange (Citrus sinensis) - 1</li>
            <li>Carrots (Daucus carota subsp. sativus) - 2</li>
            <li>Multani mitti - 2 tbsp</li>
            <li>Rose water - as needed</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grate the carrots. Extract juice from orange.</li>
            <li>Mix both juices with multani mitti.</li>
            <li>Add rose water to get a smooth paste.</li>
            <li>Apply on face. Wash off after 15 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Oranges improve skin elasticity and even out complexion.</li>
            <li>Carrots are antibacterial. They hydrate and repair skin.</li>
            <li>Multani mitti absorbs excess oils, treats pimples.</li>
            <li>Rose water tones, freshens up the skin.</li>
        </ul><br>

        <h3>Banana & Oat Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Banana (Musa acuminata) - 1</li>
            <li>Oats (Avena sativa) - 3 tbsp</li>
            <li>Milk - 2 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash banana well. Add oats and milk.</li>
            <li>Mix into a smooth scrub.</li>
            <li>Gently massage on face. Rinse off.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Banana hydrates and nourishes, suitable for dry skin.</li>
            <li>Oats exfoliate dead skin cells, reduces acne.</li>
            <li>Milk proteins soften and tighten the skin.</li>
        </ul><br>

        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>
        
        <h3>Multani Mitti & Rose Water Face Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Multani mitti - 2 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
            <li>Sandalwood (Santalum album) powder - 1⁄2 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mix multani mitti and sandalwood powder.</li>
            <li>Add rose water to make a smooth paste.</li>
            <li>Apply evenly on face and neck.</li>
            <li>Wash off when dry.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Multani mitti cleanses deep, removes excess oil.</li>
            <li>Rose water tones, refreshes and tightens skin</li>
            <li>Sandalwood powder cools and soothes skin.</li>
        </ul><br>
        """,

    "moisture":"""
    <h3>Sandalwood & Honey Face	Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Sandalwood	(Santalum album) powder	- 1	tbsp</li>
            <li> Honey - 1 tbsp</li>
            <li> Rose (Rosa centifolia)	water -	1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Mix all ingredients well.</li>
            <li> Apply pack	on	face and neck.</li>
            <li> Wash off when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Sandalwood	soothes	and	cools irritated	skin.</li>
            <li> Honey	cleanses pores,	retains	moisture.</li>
            <li> Rose	water	tones,	tightens skin.</li>
        </ul><br>
        
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

         <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>
        """,
    "clean":""" 
    <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>

            <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        """
	},


	"breakouts":{

		"Yes":{

			    "acne": """
        <h3>Neem & Turmeric Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Neem (Azadirachta indica) leaves - 1 cup</li>
            <li>Turmeric (Curcuma longa) powder - 1 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind neem leaves to a paste.</li>
            <li>Add turmeric powder and gram flour. Mix well.</li>
            <li>Add rose water gradually to get a smooth paste.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Neem is antiviral, antifungal, and antibacterial. It prevents acne and pimples.</li>
            <li>Turmeric brightens complexion and reduces pigmentation.</li>
            <li>Gram flour deeply cleanses the skin, removing dirt.</li>
        </ul><br>

            <h3>Aloe Vera & Rose Face Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Aloe Vera (Aloe barbadensis) gel - 2 tbsp</li>
            <li>Rose (Rosa centifolia) powder - 1 tsp</li>
            <li>Sandalwood (Santalum album) powder - 1⁄2 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mix all ingredients well.</li>
            <li>Apply on clean face.</li>
            <li>Wash off after 20 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Aloe vera hydrates, brightens and tightens skin.</li>
            <li>Rose powder cools, calms and evens out complexion.</li>
            <li>Sandalwood soothes irritation and reduces acne.</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

            <h3> Mint Toner for Oily Skin</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Mint (Mentha arvensis) leaves - 1 cu/li>
            <li>CApple cider vinegar - 1⁄4 cup</li>
            <li>Cucumber (Cucumis sativus) - 1⁄2</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Boil mint leaves in 2 cups water for 10 mins.</li>
            <li>Strain and let it cool.</li>
            <li>Strain and let it cool.</li>
            <li>Apply with cotton over face and neck.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Mint controls excess oil, reduces acne.</li>
            <li>Apple cider vinegar cleanses, tightens pores.</li>
            <li>Cucumber hydrates and nourishes the skin.</li>
        </ul><br>

        <h3>Banana & Oat Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Banana (Musa acuminata) - 1</li>
            <li>Oats (Avena sativa) - 3 tbsp</li>
            <li>Milk - 2 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash banana well. Add oats and milk.</li>
            <li>Mix into a smooth scrub.</li>
            <li>Gently massage on face. Rinse off.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Banana hydrates and nourishes, suitable for dry skin.</li>
            <li>Oats exfoliate dead skin cells, reduces acne.</li>
            <li>Milk proteins soften and tighten the skin.</li>
        </ul><br>

         <h3>Rose & Glycerin Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Glycerin -	1 tbsp</li>
            <li>Witch hazel	- 2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li> Boil rose	petals	in	2 cups water for 10	mins.</li>
            <li> Strain	and	let	cool. Add glycerin and	witch hazel.</li>
            <li>Transfer to	bottle	and	store in fridge.</li>
            <li>Apply daily	after cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals hydrate, cool	and	calm skin.</li>
            <li>Glycerin cleanses gently and locks	in	moisture.</li>
            <li>Witch hazel	tones skin,	reduces	acne.</li>
        </ul><br>

        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>

        <h3> Tomato & Oats Scrub</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Tomato (Solanum lycopersicum) - 1</li>
            <li>Oats (Avena sativa) - 3 tbsp</li>
            <li>Lemon (Citrus limon) juice - 1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend tomato to a smooth paste.</li>
            <li>Add oats and mix well to get a scrub.</li>
            <li>Add lemon juice and apply on face./li>
            <li>Gently scrub in circular motions. Wash off.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Tomato hydrates, evens skin tone and shrinks pores.</li>
            <li>Oats exfoliate dead cells, reduce acne.</li>
            <li>Lemon bleaches skin and tightens pores.</li>
        </ul><br>

        <h3> Papaya & Gram Flour Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Papaya (Carica papaya) - 1 cup</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend papaya to smooth paste.</li>
            <li>Add gram flour and turmeric. Mix well.</li>
            <li>Gently scrub face in circular motions.</li>
            <li>Wash off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Papaya cleanses skin, removes dead cells.</li>
            <li>Gram flour exfoliates and deeply cleanses.</li>
            <li>Turmeric antibacterial, reduces acne & scars.</li>
        </ul><br>

        <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>

        <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        </ol><br>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        </ul><br>

        <h3>Aloe Vera &	Tea	Tree Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li>Aloe vera gel -	1⁄4	cup</li>
            <li> Green	tea	- 2 bags</li>
            <li>Tea	tree essential	oil	- 3 drops</li>
        </ul><br>
         <h4> Process:</h4><br>
         <ol>
            <li>Steep green	tea	bags in	1 cup hot water	for	5 mins.</li>
            <li>Let	cool and mix with aloe vera gel.</li>
            <li> Add tea tree oil and transfer to bottle.</li>
            <li>Apply on skin after	cleansing.</li>
         </ol><br>
         <h4>Uses & Benefits:</h4><br>
         <ul>
            <li> Aloe vera soothes,	cools and hydrates.</li>
            <li> Green tea	antioxidants rejuvenate	skin.</li>
            <li> Tea tree oil	antibacterial,	prevents acne.</li>
         </ul><br>
    """,

			    "pimple":"""
        <h3>Neem & Turmeric Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Neem (Azadirachta indica) leaves - 1 cup</li>
            <li>Turmeric (Curcuma longa) powder - 1 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind neem leaves to a paste.</li>
            <li>Add turmeric powder and gram flour. Mix well.</li>
            <li>Add rose water gradually to get a smooth paste.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Neem is antiviral, antifungal, and antibacterial. It prevents acne and pimples.</li>
            <li>Turmeric brightens complexion and reduces pigmentation.</li>
            <li>Gram flour deeply cleanses the skin, removing dirt.</li>
        </ul><br>

        <h3>Orange & Carrot Face Mask</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Orange (Citrus sinensis) - 1</li>
            <li>Carrots (Daucus carota subsp. sativus) - 2</li>
            <li>Multani mitti - 2 tbsp</li>
            <li>Rose water - as needed</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grate the carrots. Extract juice from orange.</li>
            <li>Mix both juices with multani mitti.</li>
            <li>Add rose water to get a smooth paste.</li>
            <li>Apply on face. Wash off after 15 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Oranges improve skin elasticity and even out complexion.</li>
            <li>Carrots are antibacterial. They hydrate and repair skin.</li>
            <li>Multani mitti absorbs excess oils, treats pimples.</li>
            <li>Rose water tones, freshens up the skin.</li>
        </ul><br>

        <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>
    """,

			        "scars": """
        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>

        <h3> Papaya & Gram Flour Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Papaya (Carica papaya) - 1 cup</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend papaya to smooth paste.</li>
            <li>Add gram flour and turmeric. Mix well.</li>
            <li>Gently scrub face in circular motions.</li>
            <li>Wash off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Papaya cleanses skin, removes dead cells.</li>
            <li>Gram flour exfoliates and deeply cleanses.</li>
            <li>Turmeric antibacterial, reduces acne & scars.</li>
        </ul><br>
        """,

			    "clean":""" 
    <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>

            <h3>Rose & Lavender	Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Rose (Rosa	centifolia)	petals	- 1⁄4 cup</li>
            <li> Lavender (Lavandula angustifolia)	- 1⁄4 cup</li>
            <li> Witch hazel - 1⁄4	cup</li>
            <li> Glycerin -	1 tsp</li>
        <h4> Process:</h4><br>
            <li>Boil herbs	in	2 cups	water for 10 mins</li>
            <li> Strain	and	add	witch hazel.</li>
            <li> Add glycerin and pour	into bottle.</li>
            <li> Apply on face with	cotton	pad.</li>
        <h4>Uses & Benefits:</h4><br>
            <li>Rose petals	tone, tighten pores, cool skin.</li>
            <li> Lavender calms	acne, reduces redness.</li>
            <li> Witch	hazel cleanses excess	oil, bacteria.</li>
            <li>Glycerin hydrates and nourishes skin.</li>
        """
		},
	"No":""
	
	},

	"visible_pores":{

		"Yes":{
			        "pores":"""
        <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose water	tones,	tightens skin.</li>

        <h3>Sandalwood & Honey Face	Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Sandalwood	(Santalum album) powder	- 1	tbsp</li>
            <li> Honey - 1 tbsp</li>
            <li> Rose (Rosa centifolia)	water -	1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Mix all ingredients well.</li>
            <li> Apply pack	on	face and neck.</li>
            <li> Wash off when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Sandalwood	soothes	and	cools irritated	skin.</li>
            <li> Honey	cleanses pores,	retains	moisture.</li>
            <li> Rose	water	tones,	tightens skin.</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

        <h3> Cucumber &	Mint Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul> 
            <li> Cucumber (Cucumis	sativus)- 1⁄2</li>
            <li> Mint (Mentha arvensis)	-1⁄4 cup</li>
            <li> Witch	hazel - 1⁄4	cup</li>
            <li>Rose water	(Rosa centifolia) - 2 tbsp</li>
        </ul><br>
        <h4> Process:</h4><br>
            <li> Blend cucumber	and	mint leaves	with 1 cup	water.</li>
            <li> Strain	and	mix	in	witch hazel and	rose water.</li>
            <li> Pour into bottle	and	store	in	fridge.</li>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Cucumber hydrates,	soothes	and	calms skin.</li>
            <li> Mint refreshes, controls excess oil.</li>
            <li> Witch hazel tones	and	shrinks	pores.</li>
            <li> Rose water	restores pH	balance</li>
        </ul><br>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>

        <h3>Tomato & Lemon Toner</h3><br>
        <h4> Ingredients:</h4><br>
            <li>Tomato (Solanum	lycopersicum) - 1⁄2</li>
            <li> Lemon	(Citrus	limon)- 1⁄2</li>
            <li> Witch	hazel -	1⁄4	cup</li>
            <li> Aloe vera gel	- 1 tbsp</li>
        <h4>Process:</h4><br>
            <li> Blend tomatoes	and	extract	juice.</li>
            <li> Mix tomato	juice with lemon juice.</li>
            <li> Add in	witch hazel	and	aloe vera gel.</li>
            <li>Apply toner	with cotton	pad	on	skin.</li>
        <h4>Uses &	Benefits:</h4><br>
            <li> Tomato	shrinks	open pores,	balances pH.</li>
            <li>Lemon bleaches skin, deeply	cleanses</li>
            <li> Witch	hazel is antibacterial, tones skin.</li>
            <li>Aloe vera soothes and hydrates skin.</li>
    """,

			    "dead cells":"""
    <h3>Papaya-Cinnamon Exfoliating Scrub</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Papaya (Carica papaya) - 1 cup</li>
            <li>Cinnamon (Cinnamomum verum) - 1 tsp</li>
            <li>Honey - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash papaya well. Add cinnamon and honey.</li>
            <li>Mix thoroughly to get a coarse scrub.</li>
            <li>Gently scrub face in circles. Rinse with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Papaya removes dead cells, evens out skin.</li>
            <li>Cinnamon improves blood circulation giving a natural glow.</li>
            <li>Honey moisturizes and nourishes the skin.</li>
        </ul><br>

        <h3>Avocado & Yogurt Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Avocado (Persea americana) - 1⁄2</li>
            <li>Yogurt (Curd) - 1 tbsp</li>
            <li>Lemon (Citrus limon) juice - 1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Scoop out avocado pulp into a bowl.</li>
            <li>Add yogurt and lemon juice. Mix well.</li>
            <li>Apply evenly on face and neck.</li>
            <li>Wash off with water after 20 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Avocado hydrates and repairs skin, boosts collagen.</li>
            <li>Yogurt exfoliates dead cells, reduces pigmentation.</li>
            <li>Lemon brightens and tightens the skin.</li>
        </ul><br>

        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>

        <h3>Strawberry & Honey Scrub</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Strawberry (Fragaria ananassa) - 5-6</li>
            <li>Honey - 1 tbsp</li>
            <li>Sugar (Sucrose) - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash strawberries into a pulp.</li>
            <li>Add honey and sugar. Mix to a coarse scrub.</li>
            <li>Gently massage on damp face.</li>
            <li>Rinse with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Strawberry cleanses pores, exfoliates dead cells.</li>
            <li>Honey nourishes, moisturizes and softens skin.</li>
            <li>Sugar particles remove dirt and brighten skin.</li>
        </ul><br>

        <h3> Papaya & Gram Flour Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Papaya (Carica papaya) - 1 cup</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend papaya to smooth paste.</li>
            <li>Add gram flour and turmeric. Mix well.</li>
            <li>Gently scrub face in circular motions.</li>
            <li>Wash off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Papaya cleanses skin, removes dead cells.</li>
            <li>Gram flour exfoliates and deeply cleanses.</li>
            <li>Turmeric antibacterial, reduces acne & scars.</li>
        </ul><br>

        <h3>Walnut & Coffee	Scrub</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Walnut-(5-6).</li>
            <li> Coffee powder-1 tbsp</li>
            <li> Brown sugar - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Crush walnuts to coarse powder.</li>
            <li> Add coffee	and	brown sugar.</li>
            <li>Gently scrub face in circles.</li>
            <li> Rinse off	with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Walnut	exfoliates,	improves skin texture.</li>
            <li> Coffee	stimulates blood flow, rejuvenates skin.</li>
            <li> Brown	sugar removes	dead cells,	dirt.</li>
        </ul><br>

        <h3>Neem & Besan Face Pack</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Neem powder -2 tbsp</li>
            <li> Gram flour	(Cicer	arietinum) - 1 tbsp</li>
            <li>Multani	mitti- 1 tbsp</li>
            <li>Rose water (Rosa centifolia) - as needed</li>
        </ul><br>
        <h4> Process:</h4><br>
        <ol>
            <li>Mix	all	the	ingredients	together.</li>
            <li>Add	rose water to form a paste.</li>
            <li> Apply on face and	neck. Wash	off	when dry.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Neem anti-fungal,	prevents acne and pimples.</li>
            <li> Gram flour exfoliates	dead cells,	shrinks	pores.</li>
            <li>Multani	mitti cleanses	oil, dirt from deep.</li>
            <li> Rose	water	tones,	tightens	skin.</li>
        </ul><br>

        <h3>Rice Water Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Rice (Oryza sativa) -	1⁄4	cup</li>
            <li> Plain yogurt -	2 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ul>
            <li> Boil rice in 2 cups water for	15	mins.</li>
            <li> Strain	out	rice water and	let	cool</li>
            <li> Add yogurt	and	mix	well.</li>
            <li> Apply on face with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rice water	tightens pores,	smooths	wrinkles.</li>
            <li> Yogurt	hydrates, exfoliates dead cells.</li>
        </ul><br>
    """,

			        "skin texture":"""
        <h3>Walnut & Coffee	Scrub</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Walnut-(5-6).</li>
            <li> Coffee powder-1 tbsp</li>
            <li> Brown sugar - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Crush walnuts to coarse powder.</li>
            <li> Add coffee	and	brown sugar.</li>
            <li>Gently scrub face in circles.</li>
            <li> Rinse off	with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Walnut	exfoliates,	improves skin texture.</li>
            <li> Coffee	stimulates blood flow, rejuvenates skin.</li>
            <li> Brown	sugar	removes	dead	cells,	dirt.</li>
        </ul><br>
        """,
				
		},
	"No":""

	},
	
	"dull_skin":{

		"Yes":{

			    "brightens":"""
    <h3>Aloe Vera & Rose Face Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Aloe Vera (Aloe barbadensis) gel - 2 tbsp</li>
            <li>Rose (Rosa centifolia) powder - 1 tsp</li>
            <li>Sandalwood (Santalum album) powder - 1⁄2 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mix all ingredients well.</li>
            <li>Apply on clean face.</li>
            <li>Wash off after 20 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Aloe vera hydrates, brightens and tightens skin.</li>
            <li>Rose powder cools, calms and evens out complexion.</li>
            <li>Sandalwood soothes irritation and reduces acne.</li>
        </ul><br>

        <h3>Rosemary & Orange Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Rosemary (Rosmarinus officinalis)	- 1⁄4 cup</li>
            <li> Orange	(Citrus	sinensis) peel	- 2	tbsp</li>
            <li>Apple cider	vinegar	- 2	tbsp</li>
            <li>Witch hazel	- 1⁄4 cup</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ul>
             <li> Boil rosemary	and	orange	peel in	2 cups water.</li>
             <li> Strain and let cool. Mix	in	vinegar	and	witch	hazel.</li>
             <li>Transfer	to	bottle	and	refrigerate.</li>
             <li> Apply	on	skin with cotton pad.</li>
        </ul><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li> Rosemary improves	blood circulation.</li>
            <li> Orange	peel antibacterial,	brightens	skin.</li>
            <li> Apple	cider vinegar balances pH.</li>
            <li>Witch hazel	tones and firms	skin.</li>
        </ul><br>

        <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>

        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>

        <h3>Strawberry & Honey Scrub</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Strawberry (Fragaria ananassa) - 5-6</li>
            <li>Honey - 1 tbsp</li>
            <li>Sugar (Sucrose) - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Mash strawberries into a pulp.</li>
            <li>Add honey and sugar. Mix to a coarse scrub.</li>
            <li>Gently massage on damp face.</li>
            <li>Rinse with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Strawberry cleanses pores, exfoliates dead cells.</li>
            <li>Honey nourishes, moisturizes and softens skin.</li>
            <li>Sugar particles remove dirt and brighten skin.</li>
        </ul><br>
        """,

			        "refresh skin":"""
        <h3>Rose Petal & Milk Cleanser</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Rose petals	- 1⁄4 cup</li>
            <li>Milk - 2 tbsp</li>
             <li>Glycerine -	1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Grind rose petals into a paste.</li>
            <li> Add milk and glycerine. Mix well.</li>
            <li> Apply and	massage	gently on face.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Rose petals cleanse gently, refresh skin.</li>
            <li> Milk proteins soften, hydrate	and	nourish.</li>
            <li> Glycerine	cleanses, locks moisture in	skin</li>
        </ul><br>

        <h3> Mint &	Cucumber Toner</h3><br>
        <h4> Ingredients:</h4><br>
        <ol>
            <li> Mint (Mentha arvensis)	- 1⁄4 cup</li>
            <li>Cucumber - 1⁄4	cup</li>
            <li> Lemon	juice -	1 tbsp</li>
            <li> Witch	hazel -	2 tbsp</li>
        </ol><br>
        <h4> Process:</h4><br>
        <ul>
            <li>Blend mint,	cucumber and strain	juice.</li>
            <li>Mix	in lemon juice	and	witch hazel.</li>
            <li> Pour into	bottle	and	refrigerate.</li>
            <li> Apply	daily after	cleansing	with cotton	pad.</li>
        </ul><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li>Mint refreshes,	soothes	irritation.</li>
            <li> Cucumber cleanses,	hydrates, calms	skin.</li>
            <li> Lemon	juice	bleaches, tightens	pores.</li>
            <li>Witch	hazel	tones	skin, shrinks	pores.</li>
        </ul><br>
        """,

			        "skin texture":"""
        <h3>Walnut & Coffee	Scrub</h3><br>
        <h4> Ingredients:</h4><br>
        <ul>
            <li> Walnut-(5-6).</li>
            <li> Coffee powder-1 tbsp</li>
            <li> Brown sugar - 1 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Crush walnuts to coarse powder.</li>
            <li> Add coffee	and	brown sugar.</li>
            <li>Gently scrub face in circles.</li>
            <li> Rinse off	with water.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Walnut	exfoliates,	improves skin texture.</li>
            <li> Coffee	stimulates blood flow, rejuvenates skin.</li>
            <li> Brown	sugar	removes	dead	cells,	dirt.</li>
        </ul><br>
        """,

			        "pigmentation":"""
        <h3>Avocado & Yogurt Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Avocado (Persea americana) - 1⁄2</li>
            <li>Yogurt (Curd) - 1 tbsp</li>
            <li>Lemon (Citrus limon) juice - 1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Scoop out avocado pulp into a bowl.</li>
            <li>Add yogurt and lemon juice. Mix well.</li>
            <li>Apply evenly on face and neck.</li>
            <li>Wash off with water after 20 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Avocado hydrates and repairs skin, boosts collagen.</li>
            <li>Yogurt exfoliates dead cells, reduces pigmentation.</li>
            <li>Lemon brightens and tightens the skin.</li>
        </ul><br>
        """
		
		},

		"No":""

	},

	"pigmentation":{

		"Yes":{
			        "dark spots":"""
        <h3>Sandalwood & Saffron Night Serum</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Sandalwood (Santalum album) powder - 1 tbsp</li>
            <li>Saffron (Crocus sativus) strands - 5-6</li>
            <li>Almond (Prunus dulcis) oil - 2 tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Soak saffron in almond oil for 2 hours.</li>
            <li>Add sandalwood powder. Mix well.</li>
            <li>Gently massage 2-3 drops on face before sleeping.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Sandalwood cools and soothes skin overnight.</li>
            <li>Saffron improves complexion, reduces spots.</li>
            <li>Almond oil nourishes and moisturizes skin.</li>
        </ul><br>
        """,

			        "pigmentation":"""
        <h3>Avocado & Yogurt Pack</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Avocado (Persea americana) - 1⁄2</li>
            <li>Yogurt (Curd) - 1 tbsp</li>
            <li>Lemon (Citrus limon) juice - 1 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Scoop out avocado pulp into a bowl.</li>
            <li>Add yogurt and lemon juice. Mix well.</li>
            <li>Apply evenly on face and neck.</li>
            <li>Wash off with water after 20 minutes.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Avocado hydrates and repairs skin, boosts collagen.</li>
            <li>Yogurt exfoliates dead cells, reduces pigmentation.</li>
            <li>Lemon brightens and tightens the skin.</li>
        </ul><br>
        """,

			        "scars": """
        <h3> Cucumber & Yogurt Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Cucumber (Cucumis sativus) - 1</li>
            <li>Yogurt (Curd) - 2 tbsp</li>
            <li>Gram flour (Cicer arietinum) - 1 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend cucumber into a paste.</li>
            <li>Add yogurt, gram flour and turmeric. Mix well.</li>
            <li>Apply on face, massage gently for 2 mins.</li>
            <li>Rinse off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Cucumber cleanses, nourishes and hydrates skin.</li>
            <li>Yogurt exfoliates dead cells, reduces oiliness.</li>
            <li>Gram flour deeply cleanses skin removing impurities.</li>
            <li>Turmeric brightens skin, reduces acne and scars.</li>
        </ul><br>

        <h3> Papaya & Gram Flour Face Wash</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Papaya (Carica papaya) - 1 cup</li>
            <li>Gram flour (Cicer arietinum) - 2 tbsp</li>
            <li>Turmeric (Curcuma longa) - 1⁄4 tsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li>Blend papaya to smooth paste.</li>
            <li>Add gram flour and turmeric. Mix well.</li>
            <li>Gently scrub face in circular motions.</li>
            <li>Wash off with water.</li>
        </ol><br>
        <h4>Uses & Benefits:</h4><br>
        <ul>
            <li>Papaya cleanses skin, removes dead cells.</li>
            <li>Gram flour exfoliates and deeply cleanses.</li>
            <li>Turmeric antibacterial, reduces acne & scars.</li>
        </ul><br>
        """,

			    "damage":"""
    <h3>Apple &	Grape Toner</h3><br>
        <h4>Ingredients:</h4><br>
        <ul>
            <li>Apple (Malus domestica)	- 1⁄2</li>
            <li>  Grapes (Vitis	vinifera)	- 10-12</li>
            <li> Witch hazel - 1⁄4 cup</li>
            <li>Aloe vera gel	- 1	tbsp</li>
        </ul><br>
        <h4>Process:</h4><br>
        <ol>
            <li> Blend	apple &	grapes.	Strain juice.</li>
            <li>  Mix apple	grape juice	with witch	hazel.</li>
            <li>Add	aloe vera gel and store	in	fridge.</li>
            <li>  Apply	daily using	cotton	pad.</li>
        </ol><br>
        <h4> Uses &	Benefits:</h4><br>
        <ul>
            <li> Apple	enzymes	rejuvenate	and	brighten.</li>
            <li> Grapes	antioxidants repair	skin damage.</li>
            <li> Witch	hazel cleanses	pores,	reduces	acne.</li>
            <li>Aloe vera hydrates and	soothes	skin.</li>
        </ul><br>
        """	

		},

		"No":""

	}

}



def get_remedy(request):
    # Get user input from the query parameters (convert to lowercase)
    user_input = request.GET.get("user_input", "").lower()

    # Check if remedy exists in the remedies dictionary
    if user_input in remedies:
        return JsonResponse({
            "response": "Here's a remedy:",
            "remedy": remedies[user_input]
        })
    else:
        return JsonResponse({
            "response": "Sorry, no remedy found for that query."
        })

def user_login(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']
        user = authenticate(request, username=email, password=password)
        if user is not None:
            login(request, user)
            return redirect('chatbot')
        else:
            messages.error(request, "Invalid email or password")
            return redirect('login')
    return render(request, 'login.html')

def user_logout(request):
    logout(request)
    return redirect('login')

def signup(request):
    if request.method == "POST":
        email = request.POST['email']
        password = request.POST['password']
        if User.objects.filter(username=email).exists():
            messages.error(request, "Email already exists!")
            return redirect('signup')
        user = User.objects.create_user(username=email, password=password)
        user.save()
        messages.success(request, "Account created successfully! Please log in.")
        return redirect('login')
    return render(request, 'signup.html')

@login_required
def chatbot(request):
    # Handle new session
    if request.GET.get("new_session"):
        session_id = get_random_string(16)
        request.session["session_id"] = session_id
        ChatTitle.objects.create(user=request.user, session_id=session_id, title="Untitled Chat")
        return redirect("chatbot")

    # Skin analysis GET request (load form)
    if request.GET.get("analysis"):
        return render(request, "analyseqts.html", {})

    # Skin analysis remedies display from GET
    if request.GET.get("remedies"):
        remedy_list = request.GET.get("remedies").split("|")
        return render(request, "chatbot.html", {
            "remedy_list": remedy_list,
            "titles": ChatTitle.objects.filter(user=request.user).order_by("-created_at").values("title", "session_id"),
            "previous_chats": [],
            "session_ids": [],
            "selected_session": None
        })

    # Get or create session ID
    session_id = request.GET.get("session") or request.session.get("session_id")
    if not session_id:
        session_id = get_random_string(16)
        request.session["session_id"] = session_id
        ChatTitle.objects.get_or_create(user=request.user, session_id=session_id, defaults={"title": "Untitled Chat"})

    remedy_response = []
    concerns = []

    # --- Handle POST --- 
    if request.method == "POST":
        form_data = {
            "skin_type": request.POST.get("skin_type", "").strip(),
            "breakouts": request.POST.get("breakouts", "").strip(),
            "visible_pores": request.POST.get("visible_pores", "").strip(),
            "dull_skin": request.POST.get("dull_skin", "").strip(),
            "pigmentation": request.POST.get("pigmentation", "").strip()
        }
        user_query = request.POST.get("query", "").strip()
        user_input = request.POST.get("user_input", "").strip()

        # --- Skin Analysis Form ---
        if any(form_data.values()):
            selected_remedies = set()
            identified_concerns = set()

            # Skin Type Remedies
            skin_type_data = skin_analysis_remedies.get(form_data['skin_type'], {})
            if isinstance(skin_type_data, dict):
                for r in skin_type_data.values():
                    if r: selected_remedies.add(r)
                identified_concerns.add(form_data['skin_type'])

            # Other concern remedies
            for concern_key in ['breakouts', 'visible_pores', 'dull_skin', 'pigmentation']:
                concern_value = form_data[concern_key]
                concern_data = skin_analysis_remedies.get(concern_key, {}).get(concern_value, {})
                if isinstance(concern_data, dict):
                    for r in concern_data.values():
                        if r: selected_remedies.add(r)
                    identified_concerns.add(f"{concern_key.replace('_', ' ').title()}: {concern_value}")

            if not selected_remedies:
                selected_remedies.add("We couldn't find a specific remedy for your skin. Please follow general skincare practices.")

            ChatHistory.objects.create(
                user_email=request.user.username,
                query="Skin Analysis Results: " + ", ".join(sorted(identified_concerns)),
                response="\n\n".join(selected_remedies),
                session_id=session_id
            )

            SkinAnalysis.objects.create(
                user=request.user,
                session_id=session_id,
                skin_type=form_data["skin_type"],
                breakouts=form_data["breakouts"],
                visible_pores=form_data["visible_pores"],
                dull_skin=form_data["dull_skin"],
                pigmentation=form_data["pigmentation"],
                concerns=", ".join(sorted(identified_concerns)),
                remedies="\n\n".join(selected_remedies)
            )

            chat_title = ChatTitle.objects.filter(user=request.user, session_id=session_id).first()
            if chat_title and chat_title.title in ["Untitled Chat", "Skin Analysis"]:
                chat_title.title = f"Skin Analysis - {form_data['skin_type']}"
                chat_title.save()

            remedy_response = list(selected_remedies)
            concerns = sorted(identified_concerns)

        # --- AI Fallback Chat (Skin form field was blank) ---
        elif user_query:
            ai_response = get_ai_response(user_query)
            ChatHistory.objects.create(
                user_email=request.user.username,
                query=user_query,
                response=ai_response,
                session_id=session_id
            )
            remedy_response = [ai_response]

        # --- Regular Chat with user_input field ---
        elif user_input:
            bot_response = ""
            remedy_found = None

            for keyword in remedies:
                if keyword in user_input.lower():
                    remedy_found = remedies[keyword]
                    bot_response = remedy_found
                    break

            if not remedy_found:
                response = openai.Completion.create(
                    engine="text-davinci-003",
                    prompt=user_input,
                    max_tokens=150,
                    temperature=0.7
                )
                bot_response = response.choices[0].text.strip()

            ChatHistory.objects.create(
                user_email=request.user.username,
                query=user_input,
                response=bot_response,
                session_id=session_id
            )

            chat_title = ChatTitle.objects.filter(user=request.user, session_id=session_id).first()
            if chat_title and chat_title.title == "Untitled Chat":
                chat_title.title = user_input[:30] + "..." if len(user_input) > 30 else user_input
                chat_title.save()

    # Load previous chats and titles
    chats = ChatHistory.objects.filter(
        user_email=request.user.username,
        session_id=session_id
    ).order_by("timestamp")

    titles = ChatTitle.objects.filter(user=request.user).order_by("-created_at").values("title", "session_id")

    return render(request, "chatbot.html", {
        "previous_chats": chats,
        "titles": titles,
        "session_ids": [t["session_id"] for t in titles],
        "selected_session": session_id,
        "remedy": remedy_response,
        "concerns": concerns
    })


def get_ai_response(request):
    user_input = request.GET.get('user_input', '').lower()

    if not user_input:
        return JsonResponse({'status': 'error', 'message': 'Please ask a question.'})

    # Check if there's a remedy for the query
    for key in remedies:
        if key in user_input:
            return JsonResponse({'status': 'success', 'response': "Here's a remedy:", 'remedy': remedies[key]})

    # If no remedy, call OpenAI API
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=user_input,
        max_tokens=150,
        temperature=0.7
    )
    bot_response = response.choices[0].text.strip()

    return JsonResponse({'status': 'success', 'response': bot_response})


@login_required
def dashboard(request):
    analyses = SkinAnalysis.objects.filter(user=request.user)
    return render(request, 'dashboard.html', {'analyses': analyses})

def skin_analysis_success(request):
    return render(request, 'skin_analysis_success.html')  # Render success page


def skincare_tips(request):
        return render(request, 'skincare.html')

def about(request):
    return render(request, 'about.html')

def contact(request):
    return render(request, 'contact.html')

def skincare_tips(request):
    return render(request, 'skincare.html')

def weather_skincare(request):
    weather_tips = {
        'rainy': [
            "1. Cleansing & Exfoliation",
            "~Cleanse Gently – Use a mild, non-foaming cleanser to remove dirt and grime while maintaining your skin’s natural moisture. Ingredients like glycerin, aloe vera, and chamomile work best.",
            "~Exfoliate Wisely – Limit exfoliation to once or twice a week to prevent stripping away essential oils. Use mild exfoliants like oatmeal, rice powder, or fruit enzymes.",
            "~Clay Masks – Apply a clay mask once a week to absorb excess oil and unclog pores, keeping breakouts at bay.",
            "2. Hydration & Moisturizing",
            "~Lightweight, Oil-Free Moisturizer – Ditch heavy creams and opt for a light, non-greasy moisturizer to prevent clogged pores. Look for hyaluronic acid, glycerin, or aloe vera.",
            "~Hydrating Serums – Use a hydrating serum with hyaluronic acid or niacinamide to lock in moisture and prevent dehydration.",
            "~Facial Mists – Keep a refreshing facial mist with rose water or green tea to soothe and revitalize your skin throughout the day.",
            "3. Sun Protection",
            "~Sunscreen, Always – Even on cloudy days, UV rays penetrate clouds and damage the skin. Apply a broad-spectrum, water-resistant sunscreen (SPF 30 or higher).",
            "~Reapply Sunscreen – If you’re outdoors for long, reapply sunscreen every 2-3 hours for continuous protection.",
            "4. Controlling Oil & Acne",
            "~Blotting Papers – Carry blotting papers to absorb excess oil and reduce shine without disturbing your makeup.",
            "~Spot Treatment – Keep an acne spot treatment with salicylic acid or benzoyl peroxide to treat breakouts immediately.",
            "~Witch Hazel or Tea Tree Oil – Apply a witch hazel toner or diluted tea tree oil to prevent bacterial infections and acne.",
            "5. Makeup & Skincare Routine Adjustments",
            "~Avoid Heavy Makeup – Switch to a lightweight, breathable makeup routine to prevent clogged pores and breakouts.",
            "~Use Waterproof Products – Opt for waterproof foundation, mascara, and eyeliner to avoid smudging during humidity.",
            "~Minimal Powder Application – Avoid excessive compact or setting powders, as they may mix with sweat and lead to clogged pores.",
            "6. Additional Tips",
            "~Drink Plenty of Water – Staying hydrated from within ensures a healthy, glowing complexion.",
            "~Eat a Balanced Diet – Consume seasonal fruits, green vegetables, and nuts rich in antioxidants to protect your skin.",
            "~Keep Your Hands Clean – Avoid touching your face with unwashed hands to prevent bacterial infections.",
            "~Change Pillowcases Regularly – Use clean pillowcases to avoid transferring bacteria and oil onto your skin.",
            "~Use a Humidifier Indoors – If indoor air feels dry due to air conditioning, use a humidifier to maintain skin hydration.",
            

            
        ],
        'summer': [
            "1. Sun Protection is a Must:",
            "~Apply sunscreen with SPF 30-50 daily, even on cloudy days.",
            "~Reapply sunscreen if sweating or swimming",
            "~Always wear sunglasses to protect the delicate skin around your eyes.",
            "~Use a lip balm with SPF under your lipstick.",
            "~Apply sunscreen and moisturizer to your feet, especially when wearing open-toed sandals.",
            "2. Follow a Proper Cleansing Routine:",
            "~Use a mild, sulfate-free cleanser with glycerin and aloe vera to cleanse without stripping moisture.",
            "~Oily skin? Use a deep-cleansing face wash to remove excess oil.",
            "~Dry skin? Opt for a non-foaming, alcohol-free, pH-balanced cleanser.",
            "~Wash your face with lukewarm water to maintain your skin’s natural barrier.",
            "3. Hydrate and Moisturize Your Skin:",
            "~Choose a moisturizer with hyaluronic acid, ceramides, niacinamide, and antioxidants.",
            "~Use gel-based moisturizers for dry skin and water-based moisturizers for oily skin.",
            "~Apply moisturizer immediately after bathing to lock in hydration.",
            "~Use a hydrating serum to maintain a fresh, dewy look.",
            "4. Exfoliate to Keep Skin Fresh:",
            "~Exfoliate 1-2 times a week using a mild chemical exfoliant like glycolic or lactic acid.",
            "~Use a gentle face scrub to remove excess dirt and oil, and massage in circular motions.",
            "~Don’t forget to exfoliate your lips and neck too!",
            "5. Boost Skin Health with Antioxidants:",
            "~Apply a Vitamin C serum (10-20%) for skin brightening and protection.",
            "~Look for formulas with ferulic acid and vitamin E to enhance effectiveness.",
            "~Use an antioxidant serum to boost collagen and protect against environmental damage.",
            "6. Stay Hydrated & Eat Skin-Friendly Foods:",
            "~Drink at least 2-3 liters of water daily to flush out toxins.",
            "~Include coconut water, watermelons, fresh juices, yogurt, and buttermilk in your diet.",
            "~Eat cooling foods like cucumber, lettuce, and citrus fruits for glowing skin.",
            "7. Take Extra Care During Summer:",
            "~Wear light, breathable fabrics to avoid irritation.",
            "~Use a hydrating face mask at night for extra moisture.",
            "~Carry a facial mist to freshen up your skin throughout the day.",
            "~Avoid heavy makeup—opt for tinted moisturizers and lip balms instead.",
            "8. Special Care for Delicate Areas:",
            "~Use a moisturizing under-eye gel to keep the eye area hydrated.",
            "~Avoid hot water baths, as they can dry out the skin and cause irritation.",
        

        ],
        'winter': [
            "1. Moisturize Wisely",
            "~ Use a thick moisturizer to prevent dryness.",
            "~ Introduce richer creams and balms in winter to lock in moisture and nourish your skin.",
            "~ Studies from NCBI show that using a heavier, cream-based moisturizer in winter can reduce dry skin by up to 50%. Pregnant women should look for safe, gentle formulas, while men can benefit from it to prevent dry patches.",
            "~ Apply moisturizer immediately after showering to seal in hydration.",
            "~ Use a rich foot cream to address dry, cracked heels.",
            "2. Be Mindful of Your Showers",
            "~ Avoid hot showers that can strip moisture from your skin.",
            "~ Opt for lukewarm showers to maintain your skin’s natural moisture level.",
            "~ Limit shower time to 5-10 minutes to prevent excessive dryness.",
            "3. Hydration is Key",
            "~ Drink plenty of water to maintain moisture and keep your skin hydrated.",
            "~ Less water intake during winter can lead to stretchy, dried-out skin. Combat this by sipping on warm teas, water, and hydrating soups.",
            "~ Maintain your skin’s natural glow by staying hydrated throughout the colder months.",
            "4. Protect Your Skin from Harsh Winter Elements",
            "~ Protect your face from harsh winds by layering with a scarf.",
            "~ Apply a moisturizing lip balm to prevent chapped lips.",
            "~ Wear gloves to protect your hands from cold, dry air.",
            "5. Choose the Right Skincare Products",
            "~ Harsh cleansers or soaps are a major no-no. Opt for hydrating cleansers for dryness or soothing balms for sensitive skin.",
            "~ Use fragrance-free, alcohol-free products to avoid skin irritation.",
            "~ Invest in a humidifier to add moisture to the indoor air and prevent skin dryness.",
            "6. Exfoliate with Caution",
            "~ Exfoliating feels like a mini spa day, but overdoing it in winter is like scrubbing off your skin's happiness.",
            "~ Go gentle and space out exfoliation sessions to avoid turning your skin into a dead skin garden.",
            "~ Use a mild exfoliator once or twice a week to remove dead skin without stripping essential oils.",
            "7. Nutrition Matters",
            "~ A diet full of junk food, partnered with nutritional holes, will make your dry winter skin even drier.",
            "~ Feast on hydrating foods like cucumbers, oranges, and good fats like avocados, nuts, and olive oil to keep your glow game strong.",
            "~ Omega-3-rich foods, such as salmon and walnuts, help maintain skin elasticity and hydration.",
            "8. Be Aware of Underlying Causes",
            "~ Certain medical conditions or medications, such as steroids or hormonal pills, may exacerbate dry skin during winter. If this rings a bell, consult a dermatologist.",
            "~ Cold weather can trigger skin conditions like eczema and psoriasis. Keep your skincare routine gentle and nourishing to prevent flare-ups.",
            "9. Hands and Feet Need Extra Care",
            "~ Frequent washing, especially with harsh soaps, removes natural hydration from your skin.",
            "~ Moisturize often and wear gloves to avoid dry hands during winter.",
            "~ Apply a thick layer of foot cream before bed and wear socks to lock in moisture.",
            "10. Special Nighttime Care",
            "~ Use overnight masks or sleeping creams to deeply hydrate your skin.",
            "~ Consider applying a light layer of facial oil before bed to wake up with a dewy glow.",

        ]
    }
    
    selected_weather = request.GET.get('weather', None)
    tips = weather_tips.get(selected_weather, [])

    return render(request, 'weather_skincare.html', {'tips': tips, 'selected_weather': selected_weather})


def bridal_skincare(request):
    return render(request, 'bridal_skincare.html')

def oily_skincare(request):
    tips = [
        "1. Start with a Gentle Cleanser",
        "~ A gentle cleanser is crucial to remove excess oil and impurities without stripping the skin. Avoid harsh soaps that can cause the skin to overproduce oil.",
        "Recommended Ingredients:",
        "~ Salicylic acid – Penetrates deep into pores to remove oil and prevent acne.",
        "~ Tea tree oil – Has antibacterial properties to fight acne-causing bacteria.",
        "2. Apply a Toner to Balance Your Skin",
        "~ A good toner helps restore pH balance, tighten pores, and remove excess oil. Avoid toners with alcohol, as they can irritate the skin.",
        "Recommended Ingredients:",
        "~ Witch hazel – A natural astringent that controls oil without drying the skin.",
        "~ Niacinamide – Helps regulate oil production and strengthens the skin barrier.",
        "3. Use a Lightweight, Oil-Free Moisturizer",
        "~ Even oily skin needs hydration! Skipping moisturizer can lead to increased oil production as the skin tries to compensate.",
        "Recommended Ingredients:",
        "~ Hyaluronic acid – Hydrates the skin without making it greasy.",
        "~ Glycerin – A humectant that keeps skin moisturized.",
        "4. Don’t Skip Sunscreen",
        "~ Sunscreen is essential, even for oily skin. Choose a lightweight, oil-free formula that won’t clog pores.",
        "Recommended Ingredients:",
        "~ Zinc oxide – Provides sun protection without causing breakouts.",
        "~ Titanium dioxide – A non-comedogenic ingredient for broad-spectrum protection.",
        "5. Exfoliate Regularly (But Not Too Often)",
        "~ Exfoliating helps remove dead skin cells, unclog pores, and prevent breakouts. However, over-exfoliating can irritate the skin and increase oil production.",
        "Recommended Ingredients:",
        "~ Salicylic acid – A BHA that clears out oil and debris from pores.",
        "~ Glycolic acid – An AHA that exfoliates the skin’s surface.",
        "Recommended Frequency:",
        "~ 1-2 times a week (for most skin types).",
        "~ 2-3 times a week (if your skin can tolerate it).",
        "6. Use a Weekly Face Mask",
        "~ A face mask can help absorb excess oil and deep-clean pores.",
        "Recommended Ingredients:",
        "~ Clay (bentonite or kaolin) – Absorbs oil and purifies the skin.",
        "~ Charcoal – Detoxifies the skin and removes impurities.",
        "Recommended Frequency:",
        "~ Once a week for best results.",
        "7. Treat Specific Skin Concerns (Optional)",
        "~ For those prone to acne, incorporating targeted treatments can help control oil production and prevent breakouts.",
        "Recommended Ingredients:",
        "~ Retinol – Helps reduce oil production and prevent acne.",
        "~ Benzoyl peroxide – Kills acne-causing bacteria and reduces inflammation.",
        "8. Control Oil Throughout the Day",
        "~ Use blotting papers to absorb excess oil.",
        "~ Apply a mattifying primer before makeup.",
        "~ Drink plenty of water and maintain a balanced diet.",
        "10 Simple FAQs on Skincare for Oily Skin",
        "~ What’s the best cleanser for oily skin?",
        "~ A gel-based or foaming cleanser with salicylic acid.",
        "Should I use a toner?",
        "~ Yes, witch hazel or niacinamide helps control oil.",
        "Do I need to moisturize if I have oily skin?",
        "~ Yes, use a lightweight, oil-free moisturizer.",
        "How often should I exfoliate?",
        "~ 1-2 times a week to prevent clogged pores.",
        "Is sunscreen necessary for oily skin?",
        "~ Yes, use an oil-free sunscreen.",
        "How can I reduce oil during the day?",
        "~ Use blotting papers or a mattifying primer.",
        "Can oily skin cause acne?",
        "~ Yes, excess oil can clog pores and cause breakouts.",
        "Can I use oils on oily skin?",
        "~ Yes, opt for non-comedogenic oils like jojoba oil.",
        "How long until I see results from my skincare routine?",
        "~ Around 4-6 weeks with consistency.",
        "Should I change my routine for different seasons?",
        "~ Yes, use lighter products in summer and richer moisturizers in winter."
    ]
    return render(request, 'oily_skincare.html', {'tips': tips})

def anti_aging_tips(request):
    return render(request, 'anti_aging_tips.html')

def dry_skin_care(request):
    return render(request, 'dry_skin_care.html')

def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('thank_you')
    else:
        form = FeedbackForm()
    return render(request, 'feedback_form.html', {'form': form})

def feedback_thanks(request):
    return render(request, 'thank_you.html')

def remedy_detail(request):
    remedy_name = request.GET.get('remedy_name', '').strip().lower()
    remedy_data = remedies.get(remedy_name)

    return render(request, 'remedy_detail.html', {
        'remedy_name': remedy_name.capitalize(),
        'remedy_data': remedy_data or "Sorry, we couldn't find a remedy for your query.",
    })

def generate_chat_title(prompt):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Summarize this conversation topic in 5 words or less: {prompt}",
        max_tokens=10,
        temperature=0.5
    )
    return response.choices[0].text.strip()


