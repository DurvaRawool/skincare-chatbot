from django.urls import path
from . import views
from .views import user_logout

urlpatterns = [
    path('', views.chatbot, name='chatbot'), 
    path('get_ai_response/', views.get_ai_response, name='get_ai_response'),
    path('login/', views.user_login, name='login'),
    path('logout/', user_logout, name='logout'),
    path('signup/', views.signup, name='signup'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('skin-analysis-success/', views.skin_analysis_success, name='skin_analysis_success'),
    path('skincare-tips/', views.skincare_tips, name='skincare_tips'),
    path('about/', views.about, name='about'),
    path('contact/', views.contact, name='contact'),
    path('weather-skincare/', views.weather_skincare, name='weather_skincare'),
    path('bridal-skincare/', views.bridal_skincare, name='bridal_skincare'),
    path('oily-skincare/', views.oily_skincare, name='oily_skincare'),
    path('anti-aging-tips/', views.anti_aging_tips, name='anti_aging_tips'),
    path('dry-skin-care/', views.dry_skin_care, name='dry_skin_care'),
    path('remedy-detail/', views.remedy_detail, name='remedy_detail'),
    path('remedy/', views.get_remedy, name='get_remedy'),
    path('feedback_form/', views.feedback_view, name='feedback_form'),
    path('thank-you/', views.feedback_thanks, name='thank_you'),
]
